import pandas as pd
import numpy as np
pd.set_option('display.max_columns', None)

# Read the CSV file
df = pd.read_csv('Hotel_Reviews_Sample.csv')

# rawdata_process
rawdata_df = df.copy()
rawdata_df = rawdata_df.rename(columns={
    'Hotel_Name': 'hotelname',
    'Hotel_Address': 'hotel_address',
    'Average_Score': 'avg_score',
    'Additional_Number_of_Scoring': 'TNS',
    'Total_Number_of_Reviews': 'TNR',
    'lng': 'lon',
    'Review_Date': 'review_date',
    'Reviewer_Nationality': 'reviewer_nationality',
    'Negative_Review': 'NR',
    'Review_Total_Negative_Word_Counts': 'NWC',
    'Positive_Review': 'PR',
    'Review_Total_Positive_Word_Counts': 'PWC',
    'Total_Number_of_Reviews_Reviewer_Has_Given': 'RRC_history',
    'Reviewer_Score': 'reviewer_score',
    'Tags': 'tags',
    'days_since_review': 'days_since_review'
})
rawdata_df['review_date'] = pd.to_datetime(rawdata_df['review_date'])

def convert_and_compare(value):
    try:
        return 1 if int(value) > 1 else 0
    except ValueError:
        return 0

rawdata_df['if_active'] = rawdata_df['RRC_history'].apply(convert_and_compare)


# hotel DataFrame
hotel_df = rawdata_df.drop_duplicates(subset=['hotelid'])
hotel_df = hotel_df.dropna(subset=['lat', 'lon'])[['hotelid', 'hotelname', 'hotel_address', 'avg_score', 'TNS', 'TNR', 'lat', 'lon']]
hotel_com_df = hotel_df.copy().rename(columns={
    'hotelid': 'competitor_hotelid',
    'hotelname': 'competitor_hotelname',
    'lat': 'competitor_lat',
    'lon': 'competitor_lon',})

# competitor DataFrame
# Adding a dummy key to both dataframes
hotel_df['key'] = 0
hotel_com_df['key'] = 0

# Perform the merge (this will act like a Cartesian product)
competitor_df = pd.merge(hotel_df, hotel_com_df, how='outer', on='key')

# Drop the key column
competitor_df.drop('key', axis=1, inplace=True)

# Calculate distance_km using Haversine formula
competitor_df['distance_km'] = competitor_df.apply(lambda row: np.round(6378.137 * 2 * np.arcsin(
    np.sqrt(
        np.power(np.sin((row['lat'] * np.pi / 180 - row['competitor_lat'] * np.pi / 180) / 2), 2)
        + np.cos(row['lat'] * np.pi / 180)
        * np.cos(row['competitor_lat'] * np.pi / 180)
        * np.power(np.sin((row['lon'] * np.pi / 180 - row['competitor_lon'] * np.pi / 180) / 2),2)
    )
),2), axis=1)

# competitor5 DataFrame with distance_km <= 5
competitor5_df = competitor_df[
    (competitor_df['distance_km'] <= 5) & (competitor_df['hotelid'] != competitor_df['competitor_hotelid'])].copy()

# Competition level based on distance_km
competitor5_df['competition_level'] = competitor5_df['distance_km'].apply(
    lambda distance: 0 if distance < 1 else 1 if distance < 2 else 2 if distance < 3 else 3 if distance < 4 else 5)

#print(competitor_df.info())
#print(competitor5_df.loc[competitor5_df['hotelid']=='1'])
#print(competitor_df[competitor_df['distance_km'] <= 5])
#print(competitor_df[competitor_df['hotelid'] != competitor_df['competitor_hotelid']])

##################################  PARAMETERS (for testing) ##################################
'''
startdate='2016-08-01'
enddate='2017-07-31'
hotelname='Strand Palace Hotel'
competition_level=[0,1,2,3,4]
competitor_hotelname_list=['Park Plaza Westminster Bridge London']
'''
###############################################################################################

# Define function to find hotelid for hotelname
def hotelid_mapping(hotelname):
    try:
        hotelid = hotel_df.loc[hotel_df['hotelname'] == hotelname]['hotelid']
        return int(hotelid.iloc[0])
    except IndexError:
        print(f"No hotel id found for hotel name: {hotelname}")
        return None
#print(hotelid_mapping('Britannia International Hotel Canary Wharf'))

def compute_ids_and_dates(hotelname, competitor_hotelname_list, competition_level, startdate, enddate):
    hotelid = hotelid_mapping(hotelname)

    if not competitor_hotelname_list:
        competitor_hotelid_list = competitor5_df[
            (competitor5_df['competition_level'].isin(competition_level)) & 
            (competitor5_df['competitor_hotelname'] != hotelname)  
        ]['competitor_hotelid'].tolist()
    else:
        mapped_hotelids = [hotelid_mapping(hotelname) for hotelname in competitor_hotelname_list]
        competitor_hotelid_list = competitor5_df[
            (competitor5_df['competition_level'].isin(competition_level)) & 
            (competitor5_df['competitor_hotelid'].isin(mapped_hotelids)) &
            (competitor5_df['competitor_hotelname'] != hotelname)
        ]['competitor_hotelid'].tolist()

    startdate_LY = pd.to_datetime(startdate) - pd.DateOffset(years=1)
    enddate_LY = pd.to_datetime(enddate) - pd.DateOffset(years=1)

    num_days = (pd.to_datetime(enddate) - pd.to_datetime(startdate)).days + 1
    num_days_LY = (pd.to_datetime(enddate_LY) - pd.to_datetime(startdate_LY)).days + 1

    return hotelid, competitor_hotelid_list, startdate_LY, enddate_LY, num_days, num_days_LY

def filter_data_based_on_selection(hotelid, competitor_hotelid_list, startdate, enddate, startdate_LY, enddate_LY):
    # Hotel Data Filtering
    hotel_filtered = competitor5_df.loc[
        (competitor5_df['hotelid'] == hotelid) 
        & competitor5_df['competitor_hotelid'].isin(competitor_hotelid_list)
    ].reset_index()

    # Data Filtering for the Selected Period
    data_filtered = rawdata_df.loc[
        (rawdata_df['hotelid'] == hotelid) 
        & (rawdata_df['review_date'] >= startdate) 
        & (rawdata_df['review_date'] <= enddate)
    ].reset_index()

    # Competitors' Data Filtering for the Selected Period
    comps_data_filtered = rawdata_df.loc[
        (rawdata_df['hotelid'].isin(competitor_hotelid_list)) 
        & (rawdata_df['review_date'] >= startdate) 
        & (rawdata_df['review_date'] <= enddate)
    ].reset_index()

    # Data Filtering for the Last Year's Period
    LY_data_filtered = rawdata_df.loc[
        (rawdata_df['hotelid'] == hotelid) 
        & (rawdata_df['review_date'] >= startdate_LY) 
        & (rawdata_df['review_date'] <= enddate_LY)
    ].reset_index()

    # Count of unique 'hotelid' values for competitors
    comps_cnt = comps_data_filtered['hotelid'].nunique()

    return hotel_filtered, data_filtered, comps_data_filtered, LY_data_filtered, comps_cnt

########################################

########## data aggregating ############

# table 1 - overview
def aggregate_all(df):
    aggregated_data = pd.Series({
        'Score_cnt': df['reviewer_score'].count(),
        'Score_sum': df['reviewer_score'].sum(),
        'NWC_sum': df['NWC'].sum(),
        'PWC_sum': df['PWC'].sum(),
        'Active_reviewer_cnt': df['if_active'].sum()
    })

    #aggregated_data['Avg_Score'] = aggregated_data['Score_sum'] / aggregated_data['Score_cnt']
    aggregated_data['total_word_count'] = aggregated_data['NWC_sum'] + aggregated_data['PWC_sum']
    return aggregated_data.to_frame().T


def addcolumn(df):
    """
    Add specific columns to the given dataframe.
    """
    df['Avg_Score'] = df['Score_sum'] / df['Score_cnt']
    df['Avg_Word_cnt'] = df['total_word_count'] / df['Score_cnt']
    df['Pos_Word_pct'] = df['PWC_sum'] / df['total_word_count']
    df['Active_review_rate'] = df['Active_reviewer_cnt'] / df['Score_cnt']
    df['Interaction_rate'] = 0.5
    return df


def compute_aggregated_data(data_filtered, comps_data_filtered, LY_data_filtered, comps_cnt):
    def aggregate_all(df):
        aggregated_data = pd.Series({
            'Score_cnt': df['reviewer_score'].count(),
            'Score_sum': df['reviewer_score'].sum(),
            'NWC_sum': df['NWC'].sum(),
            'PWC_sum': df['PWC'].sum(),
            'Active_reviewer_cnt': df['if_active'].sum()
        })
        aggregated_data['total_word_count'] = aggregated_data['NWC_sum'] + aggregated_data['PWC_sum']
        return aggregated_data.to_frame().T

    target_data = aggregate_all(data_filtered)
    comps_data = aggregate_all(comps_data_filtered)
    LY_data = aggregate_all(LY_data_filtered)

    comps_data.loc[:, comps_data.columns] /=  comps_cnt

    target_data_final = addcolumn(target_data.copy())
    comps_data_final = addcolumn(comps_data.copy())
    LY_data_final = addcolumn(LY_data.copy())

    target_data_final['target'] = 'target'
    comps_data_final['target'] = 'comps'
    LY_data_final['target'] = 'LY'

    final_data_combined = pd.concat([target_data_final, comps_data_final, LY_data_final], ignore_index=True)

    def normalize(df):
        df_new = df[["Avg_Score",'Score_cnt',"Avg_Word_cnt","Pos_Word_pct", "Interaction_rate","Active_review_rate"]].copy()
        df_new["Avg_Score"] = round(df["Avg_Score"], 1)
        df_new["Interaction_rate"] = round(df["Interaction_rate"] * 10, 1)
        df_new["Pos_Word_pct"] = round(df["Pos_Word_pct"] * 10, 1)
        df_new["Avg_Word_cnt"] = df["Avg_Word_cnt"].apply(lambda x: round(x / 10, 1) if x <= 100 else 10)
        df_new["Active_review_rate"] = round(df["Active_review_rate"] * 10, 1)
        df_new["Score_cnt"] = round(df["Score_cnt"]/final_data_combined["Score_cnt"].max() * 10,1)
        return df_new

    target_data_normalized = normalize(target_data_final)
    comps_data_normalized = normalize(comps_data_final)
    LY_data_normalized = normalize(LY_data_final)

    return target_data_final, comps_data_final, LY_data_final, target_data_normalized, comps_data_normalized, LY_data_normalized


# Printing the final result
#print(target_data_normalized)

# table 2 - by review_date
def aggregate_data_by_timeframes(data_filtered, comps_data_filtered, LY_data_filtered, comps_cnt, startdate, enddate):

    def aggregate_by_date(df):
        aggregated_data = df.groupby(['review_date']).agg(
            Score_cnt=('reviewer_score', 'count'),
            Score_sum=('reviewer_score', 'sum'),
            NWC_sum=('NWC', 'sum'),
            PWC_sum=('PWC', 'sum'),
            Active_reviewer_cnt=('if_active', 'sum'),
        ).reset_index()
        aggregated_data['total_word_count'] = aggregated_data['NWC_sum'] + aggregated_data['PWC_sum']
        return aggregated_data

    target_data_bydate = aggregate_by_date(data_filtered)
    comps_data_bydate = aggregate_by_date(comps_data_filtered)
    LY_data_bydate = aggregate_by_date(LY_data_filtered)

    comps_data_bydate.loc[:, ~comps_data_bydate.columns.isin(['review_date'])] /= comps_cnt

    dates = pd.date_range(start=startdate, end=enddate)
    dates_df = pd.DataFrame(dates, columns=['review_date'])
    LY_data_bydate['review_date'] += pd.DateOffset(years=1)

    target_data_joined = dates_df.merge(target_data_bydate, on='review_date', how='left')
    comps_data_joined = dates_df.merge(comps_data_bydate, on='review_date', how='left')
    LY_data_joined = dates_df.merge(LY_data_bydate, on='review_date', how='left')

    def add_aggregation_columns(df):
        df['review_date'] = pd.to_datetime(df['review_date'])
        df['year_month'] = df['review_date'].dt.to_period('M')
        df['year_week'] = df['review_date'].dt.year.astype(str) + '-W' + df['review_date'].dt.isocalendar().week.astype(str).str.zfill(2)
        return df

    target_data_bydate_add = add_aggregation_columns(target_data_joined)
    comps_data_bydate_add = add_aggregation_columns(comps_data_joined)
    LY_data_bydate_add = add_aggregation_columns(LY_data_joined)

    columns_month = ['year_month', 'Score_cnt', 'Score_sum', 'NWC_sum', 'PWC_sum', 'Active_reviewer_cnt', 'total_word_count']
    columns_week = ['year_week', 'Score_cnt', 'Score_sum', 'NWC_sum', 'PWC_sum', 'Active_reviewer_cnt', 'total_word_count']

    target_data_month = target_data_bydate_add[columns_month].groupby('year_month').sum().reset_index()
    comps_data_month = comps_data_bydate_add[columns_month].groupby('year_month').sum().reset_index()
    LY_data_month = LY_data_bydate_add[columns_month].groupby('year_month').sum().reset_index()

    target_data_week = target_data_bydate_add[columns_week].groupby('year_week').sum().reset_index()
    comps_data_week = comps_data_bydate_add[columns_week].groupby('year_week').sum().reset_index()
    LY_data_week = LY_data_bydate_add[columns_week].groupby('year_week').sum().reset_index()

    def addcolumn(df):
        df['Avg_Score'] = df['Score_sum'] / df['Score_cnt']
        df['Avg_Word_cnt'] = df['total_word_count'] / df['Score_cnt']
        df['Pos_Word_pct'] = df['PWC_sum'] / df['total_word_count']
        df['Active_review_rate'] = df['Active_reviewer_cnt'] / df['Score_cnt']
        df['Interaction_rate'] = 0.5
        return df

    target_data_month_final = addcolumn(target_data_month.copy())
    comps_data_month_final = addcolumn(comps_data_month.copy())
    LY_data_month_final = addcolumn(LY_data_month.copy())

    target_data_week_final = addcolumn(target_data_week.copy())
    comps_data_week_final = addcolumn(comps_data_week.copy())
    LY_data_week_final = addcolumn(LY_data_week.copy())

    return target_data_month_final, comps_data_month_final, LY_data_month_final, target_data_week_final, comps_data_week_final, LY_data_week_final


#print(target_data_month_final)
# Adding the 'target' column to distinguish them
#target_data_joined['target'] = 'target'
#comps_data_joined['target'] = 'comps'
#LY_data_joined['target'] = 'LY'

# Concatenating the three DataFrames into a single DataFrame
#final_data_bydate = pd.concat([target_data_joined, comps_data_joined, LY_data_joined], ignore_index=True)

# Printing the final result
#print(final_data_bydate)


# table 3 - by reviewer_nationality
def aggregate_data_by_country(data_filtered, comps_data_filtered, LY_data_filtered, comps_cnt):

    def aggregate_by_rcountry(df):
        aggregated_data = df.groupby(['reviewer_nationality']).agg(
            Score_cnt=('reviewer_score', 'count'),
            Score_sum=('reviewer_score', 'sum'),
            NWC_sum=('NWC', 'sum'),
            PWC_sum=('PWC', 'sum'),
            Active_reviewer_cnt=('if_active', 'sum'),
        ).reset_index()

        aggregated_data['total_word_count'] = aggregated_data['NWC_sum'] + aggregated_data['PWC_sum']
        return aggregated_data

    target_data_byrcountry = aggregate_by_rcountry(data_filtered)
    comps_data_byrcountry = aggregate_by_rcountry(comps_data_filtered)
    LY_data_byrcountry = aggregate_by_rcountry(LY_data_filtered)

    comps_data_byrcountry.loc[:, ~comps_data_byrcountry.columns.isin(['reviewer_nationality'])] /= comps_cnt

    def addcolumn(df):
        df['Avg_Score'] = df['Score_sum'] / df['Score_cnt']
        df['Avg_Word_cnt'] = df['total_word_count'] / df['Score_cnt']
        df['Pos_Word_pct'] = df['PWC_sum'] / df['total_word_count']
        df['Active_review_rate'] = df['Active_reviewer_cnt'] / df['Score_cnt']
        df['Interaction_rate'] = 0.5
        return df

    target_map_data_final = addcolumn(target_data_byrcountry.copy())
    comps_map_data_final = addcolumn(comps_data_byrcountry.copy())
    LY_map_data_final = addcolumn(LY_data_byrcountry.copy())

    return target_map_data_final, comps_map_data_final, LY_map_data_final


# Adding the 'target' column to distinguish them
#target_data_byrcountry['target'] = 'target'
#comps_data_byrcountry['target'] = 'comps'
#LY_data_byrcountry['target'] = 'LY'

# Concatenating the three DataFrames into a single DataFrame
#final_data_byrcountry = pd.concat([target_data_byrcountry, comps_data_byrcountry, LY_data_byrcountry], ignore_index=True)

# Printing the final result
#print(target_data_byrcountry)

# table 4 - text analysis
#NMF
import nltk
from nltk.stem import SnowballStemmer
from nltk.corpus import stopwords
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.decomposition import NMF
import pandas as pd
from scipy.sparse import hstack

def process_reviews(data_filtered):
    # Convert the reviews to lists
    positive_reviews = data_filtered["PR"].dropna().tolist()
    negative_reviews = data_filtered["NR"].dropna().tolist()

    # Define stop words
    def get_stopwords():
        stop_words = set(stopwords.words('english'))
        stop_words.update(["hotel", "room", "positive", "negative", "t", "nothing", "could", "got", "day", "date", "couldnt"])
        words_to_include = ["AC"]
        return stop_words - set(words_to_include)

    STOPWORDS = get_stopwords()
    stemmer = SnowballStemmer('english')

    # 1. Preprocessing function
    def preprocess(reviews):
        processed_reviews = []
        for review in reviews:
            review = review.lower()
            tokens = nltk.word_tokenize(review)
            tokens = [stemmer.stem(token) for token in tokens if token not in STOPWORDS and len(token) > 1]
            processed_reviews.append(' '.join(tokens))
        return processed_reviews

    # 2. Create TF-IDF vectors
    def tfidf_vectors(processed_reviews):
        tfidf_vectorizer_unigram = TfidfVectorizer(min_df=2, ngram_range=(1,1))
        tfidf_unigram = tfidf_vectorizer_unigram.fit_transform(processed_reviews)
        tfidf_vectorizer_bigram = TfidfVectorizer(min_df=2, ngram_range=(2,2), vocabulary=tfidf_vectorizer_unigram.get_feature_names_out())
        tfidf_bigram = tfidf_vectorizer_bigram.fit_transform(processed_reviews)
        return hstack([tfidf_unigram, tfidf_bigram]), tfidf_vectorizer_unigram, tfidf_vectorizer_bigram

    # 3. Create and fit NMF model
    def create_nmf_model(tfidf_combined, n_topics=5):
        nmf = NMF(n_components=n_topics)
        nmf.fit(tfidf_combined)
        return nmf

    # Convert the results into a DataFrame
    def results_to_dataframe(model, vectorizer_unigram, vectorizer_bigram, n=5):
        terms = list(vectorizer_unigram.get_feature_names_out()) + list(vectorizer_bigram.get_feature_names_out())
        factors, top_terms_list = [], []
        for i, comp in enumerate(model.components_):
            terms_in_comp = zip(terms, comp)
            sorted_terms = sorted(terms_in_comp, key=lambda x: -x[1])[:n]
            top_terms = ", ".join([term for term, _ in sorted_terms])
            factors.append(f"Factor {i+1}")
            top_terms_list.append(top_terms)
        return pd.DataFrame({
            'Factor': factors,
            'Top Terms': top_terms_list,
        })

    # Main process
    processed_pos_reviews = preprocess(positive_reviews)
    processed_neg_reviews = preprocess(negative_reviews)
    tfidf_pos_combined, uni_vectorizer_pos, bi_vectorizer_pos = tfidf_vectors(processed_pos_reviews)
    tfidf_neg_combined, uni_vectorizer_neg, bi_vectorizer_neg = tfidf_vectors(processed_neg_reviews)
    nmf_pos = create_nmf_model(tfidf_pos_combined)
    nmf_neg = create_nmf_model(tfidf_neg_combined)
    df_pos = results_to_dataframe(nmf_pos, uni_vectorizer_pos, bi_vectorizer_pos)
    df_neg = results_to_dataframe(nmf_neg, uni_vectorizer_neg, bi_vectorizer_neg)

    return df_pos, df_neg


'''
#LSA
import nltk
from nltk.stem import SnowballStemmer
from nltk.corpus import stopwords
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.decomposition import TruncatedSVD
import pandas as pd
from scipy.sparse import hstack

def process_reviews(data_filtered):
    # Convert the reviews to lists
    positive_reviews = data_filtered["PR"].dropna().tolist()
    negative_reviews = data_filtered["NR"].dropna().tolist()

    # Define stop words
    def get_stopwords():
        stop_words = set(stopwords.words('english'))
        stop_words.update(["hotel", "room", "positive", "negative", "t", "nothing", "could", "got", "day", "date", "couldnt"])
        words_to_include = ["AC"]
        return stop_words - set(words_to_include)

    STOPWORDS = get_stopwords()
    stemmer = SnowballStemmer('english')

    # 1. Preprocessing function
    def preprocess(reviews):
        processed_reviews = []
        for review in reviews:
            review = review.lower()
            tokens = nltk.word_tokenize(review)
            tokens = [stemmer.stem(token) for token in tokens if token not in STOPWORDS and len(token) > 1]
            processed_reviews.append(' '.join(tokens))
        return processed_reviews

    # 2. Create TF-IDF vectors
    def tfidf_vectors(processed_reviews):
        tfidf_vectorizer_unigram = TfidfVectorizer(min_df=2, ngram_range=(1,1))
        tfidf_unigram = tfidf_vectorizer_unigram.fit_transform(processed_reviews)
        tfidf_vectorizer_bigram = TfidfVectorizer(min_df=2, ngram_range=(2,2), vocabulary=tfidf_vectorizer_unigram.get_feature_names_out())
        tfidf_bigram = tfidf_vectorizer_bigram.fit_transform(processed_reviews)
        return hstack([tfidf_unigram, tfidf_bigram]), tfidf_vectorizer_unigram, tfidf_vectorizer_bigram

    # 3. Create and fit LSA model
    def create_lsa_model(tfidf_combined, n_topics=5):
        lsa = TruncatedSVD(n_components=n_topics)
        lsa.fit(tfidf_combined)
        return lsa

    # Convert the results into a DataFrame
    def results_to_dataframe(model, vectorizer_unigram, vectorizer_bigram, n=5):
        terms = list(vectorizer_unigram.get_feature_names_out()) + list(vectorizer_bigram.get_feature_names_out())
        factors, singular_values, top_terms_list = [], [], []
        for i, comp in enumerate(model.components_):
            terms_in_comp = zip(terms, comp)
            sorted_terms = sorted(terms_in_comp, key=lambda x: -x[1])[:n]
            top_terms = ", ".join([term for term, _ in sorted_terms])
            factors.append(f"Factor {i+1}")
            singular_values.append(round(model.singular_values_[i],2))
            top_terms_list.append(top_terms)
        return pd.DataFrame({
            'Factor': factors,
            'Singular Value': singular_values,
            'Top Terms': top_terms_list,
        })

    # Main process
    processed_pos_reviews = preprocess(positive_reviews)
    processed_neg_reviews = preprocess(negative_reviews)
    tfidf_pos_combined, uni_vectorizer_pos, bi_vectorizer_pos = tfidf_vectors(processed_pos_reviews)
    tfidf_neg_combined, uni_vectorizer_neg, bi_vectorizer_neg = tfidf_vectors(processed_neg_reviews)
    lsa_pos = create_lsa_model(tfidf_pos_combined)
    lsa_neg = create_lsa_model(tfidf_neg_combined)
    df_pos = results_to_dataframe(lsa_pos, uni_vectorizer_pos, bi_vectorizer_pos)
    df_neg = results_to_dataframe(lsa_neg, uni_vectorizer_neg, bi_vectorizer_neg)

    return df_pos, df_neg
'''