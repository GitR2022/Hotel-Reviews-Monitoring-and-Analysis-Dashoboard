from app import data_filtered
import pandas as pd
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer, CountVectorizer
from sklearn.decomposition import TruncatedSVD, NMF, LatentDirichletAllocation as LDA
from scipy.sparse import hstack
import nltk
from nltk.stem import SnowballStemmer
from nltk.corpus import stopwords

# Assuming positive_reviews and negative_reviews are lists of reviews
def filter_and_preprocess(reviews):
    filtered_reviews = [review for review in reviews if not any(phrase in review.lower() for phrase in ["nothing", "no positive", "no negative"])]
    return filtered_reviews

positive_reviews = filter_and_preprocess(data_filtered["PR"].dropna().tolist())
negative_reviews = filter_and_preprocess(data_filtered["NR"].dropna().tolist())

def get_stopwords():
    stop_words = set(stopwords.words('english'))
    stop_words.update(["hotel", "room", "positive", "negative", "t", "nothing", "could", "got", "day", "date", "couldnt"])
    words_to_include = ["ac"]
    return stop_words - set(words_to_include)

STOPWORDS = get_stopwords()
stemmer = SnowballStemmer('english')

def preprocess(reviews):
    processed_reviews = []
    for review in reviews:
        review = review.lower()
        tokens = nltk.word_tokenize(review)
        tokens = [stemmer.stem(token) for token in tokens if token not in STOPWORDS and len(token) > 1]
        processed_reviews.append(' '.join(tokens))
    return processed_reviews

def vectorize_data(processed_reviews, method="tfidf"):
    if method == "tfidf":
        vectorizer_unigram = TfidfVectorizer(min_df=2, ngram_range=(1,1))
        unigram = vectorizer_unigram.fit_transform(processed_reviews)
        vectorizer_bigram = TfidfVectorizer(min_df=2, ngram_range=(2,2), vocabulary=vectorizer_unigram.get_feature_names_out())
    elif method == "count":
        vectorizer_unigram = CountVectorizer(min_df=2, ngram_range=(1,1))
        unigram = vectorizer_unigram.fit_transform(processed_reviews)
        vectorizer_bigram = CountVectorizer(min_df=2, ngram_range=(2,2), vocabulary=vectorizer_unigram.get_feature_names_out())
    else:
        raise ValueError("Invalid method. Choose either 'tfidf' or 'count'.")

    bigram = vectorizer_bigram.fit_transform(processed_reviews)

    return hstack([unigram, bigram]), vectorizer_unigram, vectorizer_bigram


def create_decomposition_model(data, method="lsa", n_topics=5):
    if method == "lsa":
        model = TruncatedSVD(n_components=n_topics)
    elif method == "nmf":
        model = NMF(n_components=n_topics)
    elif method == "lda":
        model = LDA(n_components=n_topics)
    else:
        raise ValueError("Invalid method. Choose 'lsa', 'nmf', or 'lda'.")
    model.fit(data)
    return model

def print_top_terms(model, vectorizer_unigram, vectorizer_bigram, n=5, method="lsa"):
    terms = list(vectorizer_unigram.get_feature_names_out()) + list(vectorizer_bigram.get_feature_names_out())
    if method == "lda":
        components = model.components_ / model.components_.sum(axis=1)[:, np.newaxis]
    else:
        components = model.components_
        
    print("Factor", "\tTop Terms")
    for i, comp in enumerate(components):
        terms_in_comp = zip(terms, comp)
        sorted_terms = sorted(terms_in_comp, key=lambda x: -x[1])[:n]
        top_terms = ", ".join([term for term, _ in sorted_terms])
        print(f"Factor {i+1}\t\t{top_terms}")

processed_pos_reviews = preprocess(positive_reviews)

# Apply TF-IDF + LSA
tfidf_pos, uni_vectorizer_pos, bi_vectorizer_pos = vectorize_data(processed_pos_reviews, method="tfidf")
lsa_pos = create_decomposition_model(tfidf_pos, method="lsa")
print("Positive Reviews (TF-IDF + LSA):")
print_top_terms(lsa_pos, uni_vectorizer_pos, bi_vectorizer_pos)

# Apply Count + LSA
count_pos, uni_vectorizer_pos_count, bi_vectorizer_pos_count = vectorize_data(processed_pos_reviews, method="count")
lsa_pos_count = create_decomposition_model(count_pos, method="lsa")
print("\nPositive Reviews (Count + LSA):")
print_top_terms(lsa_pos_count, uni_vectorizer_pos_count, bi_vectorizer_pos_count)

# Apply TF-IDF + NMF
nmf_pos = create_decomposition_model(tfidf_pos, method="nmf")
print("\nPositive Reviews (TF-IDF + NMF):")
print_top_terms(nmf_pos, uni_vectorizer_pos, bi_vectorizer_pos)

# Apply Count + NMF
nmf_pos_count = create_decomposition_model(count_pos, method="nmf")
print("\nPositive Reviews (Count + NMF):")
print_top_terms(nmf_pos_count, uni_vectorizer_pos_count, bi_vectorizer_pos_count)

# Apply Count + LDA
lda_pos = create_decomposition_model(count_pos, method="lda")
print("\nPositive Reviews (Count + LDA):")
print_top_terms(lda_pos, uni_vectorizer_pos_count, bi_vectorizer_pos_count, method="lda")
print("\nLDA Perplexity:", lda_pos.perplexity(count_pos))

# Apply TF-IDF + LDA (this was already provided, but including for completeness)
tfidf_lda_pos = create_decomposition_model(tfidf_pos, method="lda")
print("\nPositive Reviews (TF-IDF + LDA):")
print_top_terms(tfidf_lda_pos, uni_vectorizer_pos, bi_vectorizer_pos, method="lda")
print("\nLDA Perplexity:", tfidf_lda_pos.perplexity(tfidf_pos))