from viz import generate_cards,generate_radar_chart, create_figure_for_metric, value_mapping,metric_select,create_map_for_metric,\
generate_wordcloud_figures, generate_datatables,review_card_components,create_review_card
from data import compute_ids_and_dates,filter_data_based_on_selection,aggregate_data_by_timeframes,aggregate_data_by_country,\
hotel_df,hotel_com_df,compute_aggregated_data,process_reviews
import dash
from dash import dcc, html, callback
from dash.dependencies import Output, Input, State
import plotly.express as px
import dash_bootstrap_components as dbc
import plotly.graph_objects as go
# import pandas as pd
from datetime import datetime


# https://www.bootstrapcdn.com/bootswatch/
app = dash.Dash(__name__, external_stylesheets=[dbc.themes.BOOTSTRAP,dbc.icons.BOOTSTRAP], 
                meta_tags=[{'name': 'viewport',
                            'content': 'width=device-width, initial-scale=1.0'}]
                )

##################################  PARAMETERS (for demo) ####################################
startdate='2016-08-01'
enddate='2017-07-31'
hotelname='Strand Palace Hotel'
competition_level=[0,1,2,3,4]
competitor_hotelname_list=['Park Plaza Westminster Bridge London']
###############################################################################################

hotel_list = hotel_df['hotelname'].tolist()
comp_hotel_list = hotel_com_df['competitor_hotelname'].tolist()

hotel_filter_area = dbc.Row([
    # 1. Search - Target Hotel
    dbc.Col([
        dbc.InputGroup([
            dbc.InputGroupText("Target Hotel"),
            dcc.Dropdown(
                id='target-hotel-dropdown',
                options=[{'label': hotel, 'value': hotel} for hotel in hotel_list],  # assuming you have a list of hotels called `hotel_list`
                #value=hotel_list[0] if hotel_list else None,  # default to the first hotel
                value=hotelname,  # for demo
                clearable=False,
                search_value='',
                placeholder="Select target hotel...",
                style={'width' : '70%',}
            )
        ])
    ],width = 5),
    
    # 2. Group Search - Competitor Hotel
    dbc.Col([
        dbc.InputGroup([
            dbc.InputGroupText("Competitor Hotel"),
            dcc.Dropdown(
                id='competitor-hotel-dropdown',
                options=[{'label': comp_hotel, 'value': comp_hotel} for comp_hotel in comp_hotel_list],  # assuming a list of competitor hotels
                value=competitor_hotelname_list,
                multi=True,
                placeholder="Select competing hotels...",
            ),
        ])
    ],width = 7)
], className="bg-light p-3")

date_filter_area = dbc.Row([
    # 3. Group Search - View Time Period
    dbc.Col([
        dbc.InputGroup([
            dbc.InputGroupText("Time Period"),
            dcc.DatePickerRange(
                id='date-picker-range',
                start_date=startdate,
                end_date=enddate
            )
        ]),
    ], width=9),
    
    # 4. Button group - Update&clear
    dbc.Col([
        dbc.ButtonGroup([
        dbc.Button("Update", id='update-button', color="primary"),
        dbc.Button("Clear", id='clear-button',outline=True, color="primary")
        ]),
        "  Only for display",
    ], width=3)
], className="bg-light p-3")




#preprocess
hotelid, competitor_hotelid_list, startdate_LY, enddate_LY, num_days, num_days_LY = compute_ids_and_dates(hotelname, competitor_hotelname_list, competition_level, startdate, enddate)
hotel_filtered, data_filtered, comps_data_filtered, LY_data_filtered, comps_cnt = filter_data_based_on_selection(hotelid, competitor_hotelid_list, startdate, enddate, startdate_LY, enddate_LY)
target_data_final, comps_data_final, LY_data_final, target_data_normalized, comps_data_normalized, LY_data_normalized = compute_aggregated_data(data_filtered, comps_data_filtered, LY_data_filtered, comps_cnt)
target_data_month_final, comps_data_month_final, LY_data_month_final, target_data_week_final, comps_data_week_final, LY_data_week_final = aggregate_data_by_timeframes(data_filtered, comps_data_filtered, LY_data_filtered, comps_cnt, startdate, enddate)
target_map_data_final, comps_map_data_final, LY_map_data_final = aggregate_data_by_country(data_filtered, comps_data_filtered, LY_data_filtered, comps_cnt)
#cards
cards = generate_cards(target_data_final, comps_data_final, LY_data_final, value_mapping)
#radar figure
radar = generate_radar_chart(target_data_normalized, comps_data_normalized, LY_data_normalized, value_mapping)
#wordcloud
figures = generate_wordcloud_figures(data_filtered)
#factor-table
df_pos, df_neg = process_reviews(data_filtered)
neg_factors,pos_factors = generate_datatables(df_pos, df_neg)
#review card
review_cards, positive_review_cards, sorted_reviews_and_sentiments, sorted_positive_reviews_and_sentiments = review_card_components(data_filtered)

# Layout section: Bootstrap (https://hackerthemes.com/bootstrap-cheatsheet/)
# ************************************************************************

app.layout = dbc.Container([
    dcc.Location(id='url', refresh=False),  
    html.Div(id='hidden-div', style={'display':'none'}),
    dbc.Row([
        html.H2("Hotel Reviews Monitoring and Analysis Dashboard"),
        html.Small([html.I(className="bi bi-database"),f"Data update time: 2017-08-01 08:10:07"])
    ],className="text-center"),   
    hotel_filter_area,
    date_filter_area,
    html.Div(style={'height': '10px'}),
    html.H4([html.I(className="bi bi-pie-chart-fill")," Overview"],className="text-primary fw-bold my-2 p-1"),
    dbc.Row([
        dbc.Col([
            dbc.Row([dbc.Col(cards[i], className="w-30 m-1 ms-0 g-1") for i in range(2)]),
            dbc.Row([dbc.Col(cards[i], className="w-30 m-1 ms-0 g-1") for i in range(2, 4)]),
            dbc.Row([dbc.Col(cards[i], className="w-30 m-1 ms-0 g-1") for i in range(4, 6)])
        ], width=6),
        dbc.Col(dcc.Graph(figure=radar), width=6)
    ]),
    html.Hr(),
    html.Div(style={'height': '10px'}),
    html.H4([html.I(className="bi bi-bar-chart-line-fill")," Metrics-by-Dimension Visualization"],className="text-primary fw-bold my-2 p-1"), 
    metric_select,
    dbc.Row([
        dbc.Col([
            html.H6("View by Review date"),
            dcc.RadioItems(
                id='period-selector',
                options=[
                    {'label': 'Monthly', 'value': 'year_month'},
                    {'label': 'Weekly', 'value': 'year_week', 'disabled': True},
                ],
                value='year_month',
                labelStyle={'display': 'inline-block', 'margin-right': '10px'}  # Each radio item will be inline-block
            ),
            dcc.Graph(id='metric-plot-month')
        ], width=6),
        dbc.Col([
            html.Div([
                    html.H6("View by Reviewer Nationality"),
                    dcc.RadioItems(
                        id='layer-selector',
                        options=[
                            {'label': 'Target', 'value': 'Target'},
                            {'label': '% vs Comps', 'value': 'vsComps'},
                            {'label': '% vs LY', 'value': 'vsLY'}
                        ],
                        value='Target',
                        labelStyle={'display': 'inline-block', 'margin-right': '10px'}  # Each radio item will be inline-block
                    ),
                    dcc.Graph(id='choropleth-map')]),
        ], width=6),
    ]),
    html.Hr(),
    html.Div(style={'height': '10px'}),
    html.H4([html.I(className="bi bi-blockquote-left")," Text Analysis"],className="text-primary fw-bold my-2 p-1"), 
    dbc.Tabs([
        dbc.Tab([
            dbc.Row([
                dbc.Col([
                    dcc.Graph(figure=figures['negative']),
                    neg_factors,
                ], width=6),
                dbc.Col([
                    html.Div(style={'height': '10px'}),
                    review_cards
                ], width=6),
            ]),
        ],  label=" Negative Reviews"),

        dbc.Tab([
            dbc.Row([
                dbc.Col([
                    dcc.Graph(figure=figures['positive']),
                    pos_factors,
                ], width=6),
                dbc.Col([
                    html.Div(style={'height': '10px'}),
                    positive_review_cards
                ], width=6)
            ]),
        ], label="Positive Reviews"),
    ]),
])


# Callback section: connecting the components
# ************************************************************************
@app.callback(
    [Output('choropleth-map', 'figure'),
     Output('metric-plot-month', 'figure'),
     #Output('metric-plot-week', 'figure')
     ], 
    [Input('metric-selector', 'value'),
     Input('layer-selector', 'value')]
)
def update_figure(selected_index, selected_layer):
    month_fig = create_figure_for_metric('year_month', selected_index, target_data_month_final, comps_data_month_final, LY_data_month_final, value_mapping)
    #week_fig = create_figure_for_metric('year_week', selected_index, target_data_week_final, comps_data_week_final, LY_data_week_final, value_mapping)
    map_fig = create_map_for_metric(selected_layer, selected_index, target_map_data_final, comps_map_data_final, LY_map_data_final)

    return map_fig, month_fig, #week_fig

@app.callback(
    [Output('reviews-container', 'children'),
     Output('positive-reviews-container', 'children')],
    [Input('negative-search-box', 'value'),
     Input('positive-search-box', 'value'),
     Input('pagination', 'active_page'),
     Input('positive-pagination', 'active_page')]
)
def update_output(negative_search_value, positive_search_value, negative_page, positive_page):
    negative_search_value = negative_search_value or ""
    positive_search_value = positive_search_value or ""
    
    negative_filtered_reviews_and_sentiments = [(review, sentiment) for (review, sentiment) in sorted_reviews_and_sentiments if negative_search_value.lower() in review.lower()]
    positive_filtered_reviews_and_sentiments = [(review, sentiment) for (review, sentiment) in sorted_positive_reviews_and_sentiments if positive_search_value.lower() in review.lower()]

    negative_filtered_reviews, negative_filtered_sentiments = zip(*negative_filtered_reviews_and_sentiments)
    positive_filtered_reviews, positive_filtered_sentiments = zip(*positive_filtered_reviews_and_sentiments)

    if negative_filtered_reviews_and_sentiments:
        negative_filtered_reviews, negative_filtered_sentiments = zip(*negative_filtered_reviews_and_sentiments)
    else:
        negative_filtered_reviews, negative_filtered_sentiments = [], []

    if positive_filtered_reviews_and_sentiments:
        positive_filtered_reviews, positive_filtered_sentiments = zip(*positive_filtered_reviews_and_sentiments)
    else:
        positive_filtered_reviews, positive_filtered_sentiments = [], []

    start_negative_idx = (negative_page - 1) * 6
    end_negative_idx = min(len(negative_filtered_reviews), start_negative_idx + 6)
    
    start_positive_idx = (positive_page - 1) * 6
    end_positive_idx = min(len(positive_filtered_reviews), start_positive_idx + 6)

    negative_cards = [create_review_card(negative_filtered_reviews[i], negative_filtered_sentiments[i], negative_search_value) for i in range(start_negative_idx, end_negative_idx)]
    positive_cards = [create_review_card(positive_filtered_reviews[i], positive_filtered_sentiments[i], positive_search_value) for i in range(start_positive_idx, end_positive_idx)]


    return negative_cards, positive_cards


if __name__=='__main__':
    app.run(debug=True, port=8000)
