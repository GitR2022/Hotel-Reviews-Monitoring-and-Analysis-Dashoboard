'''
from data import target_data_final,comps_data_final,LY_data_final,\
    target_data_month_final,comps_data_month_final,LY_data_month_final,target_data_week_final,comps_data_week_final,LY_data_week_final,\
    target_map_data_final,comps_map_data_final,LY_map_data_final,data_filtered,\
    comps_data_filtered,df_pos,df_neg,df_comp_pos,\
    target_data_normalized,comps_data_normalized,LY_data_normalized
'''
from dash import dcc, html, dash_table
import plotly.express as px
import dash_bootstrap_components as dbc
import plotly.graph_objects as go
import pandas as pd
from textblob import TextBlob
import numpy as np
from PIL import Image
from wordcloud import WordCloud, STOPWORDS
import plotly.express as px
from collections import Counter
import random
import pycountry

value_mapping = {
    "titles":["Average Score", "Positive Word Rate", "Review Number", "Average Word Count", "Active Review Rate", "Interaction Rate"],
    "values":["Avg_Score", "Pos_Word_pct", "Score_cnt", "Avg_Word_cnt", "Active_review_rate", "Interaction_rate"],
}
metric_select = html.Div([
    dcc.Dropdown(
        id='metric-selector',
        options=[{'label': title, 'value': index} for index, title in enumerate(value_mapping["titles"])],
        value=0,
        clearable=False
    )
])

### 1 - indicator card
def generate_cards(target_data_final, comps_data_final, LY_data_final, value_mapping):
    metrics = {
        "titles": [],
        "Target": [],
        "vsComps": [],
        "vsLY": []
    }
    for i in range(0, 6):
        title = value_mapping["titles"][i]
        target_value = round(target_data_final[value_mapping["values"][i]], 1)
        vscom_value = round(
            (target_data_final[value_mapping["values"][i]].iloc[0] / comps_data_final[value_mapping["values"][i]].iloc[0] - 1) * 100, 1)
        vsly_value = round(
            (target_data_final[value_mapping["values"][i]].iloc[0] / LY_data_final[value_mapping["values"][i]].iloc[0] - 1) * 100, 1)

        metrics["titles"].append(title)
        metrics["Target"].append(target_value)
        metrics["vsComps"].append(vscom_value)
        metrics["vsLY"].append(vsly_value)

    cards = []
    for i in range(0, 6):
        vscom = metrics["vsComps"][i]
        vsly = metrics["vsLY"][i]
        vscom_icon = "bi bi-caret-down-fill" if vscom < 0 else "bi bi-caret-up-fill"
        vscom_color = "danger" if vscom < 0 else "success"
        vsly_icon = "bi bi-caret-down-fill" if vsly < 0 else "bi bi-caret-up-fill"
        vsly_color = "danger" if vsly < 0 else "success"

        card_content = [
            dbc.CardBody(
                [
                    html.P(
                        children=metrics["titles"][i],
                        style={
                            'font_size': '16px'
                        },
                        className="fw-bold"
                    ),
                    html.H4(round(metrics["Target"][i], 1), className="fw-bold"),
                    html.Small([
                        html.I(className=vscom_icon),
                        f" {vscom}%"
                    ], className=f"text-{vscom_color}"),
                    html.Small(" vs Comps    "),
                    html.Small([
                        html.I(className=vsly_icon),
                        f" {vsly}%"
                    ], className=f"text-{vsly_color}"),
                    html.Small(" vs LY"),
                ], className="text-center text-nowrap my-2 p-1 "
            )
        ]
        cards.append(dbc.Card(card_content))
    return cards


#####################################################################

### 2 - radar chart
def generate_radar_chart(target_data_normalized, comps_data_normalized, LY_data_normalized, value_mapping):
    # Function to add traces
    def add_trace(data, name, radar):
        radar.add_trace(go.Scatterpolar(
            r=[data[metric] for metric in value_mapping["values"]],
            theta=value_mapping["titles"],
            fill='toself',
            name=name
        ))

    # Selecting the rows you want to plot
    target_data = target_data_normalized.iloc[0]
    comps_data = comps_data_normalized.iloc[0]
    LY_data = LY_data_normalized.iloc[0]

    # Create Radar chart
    radar = go.Figure()

    # Add traces
    add_trace(target_data, 'You', radar)
    add_trace(comps_data, 'Competitor', radar)
    add_trace(LY_data, 'Last Year', radar)

    # Layout
    radar.update_layout(
        polar=dict(
            radialaxis=dict(
                visible=True,
                # range=[0, 100]
            )),
        showlegend=True
    )
    
    return radar

#####################################################################
### 3 - line and bar chart

def create_figure_for_metric(period, selected_index, target_df, comps_df, LY_df, value_mapping):
    fig = go.Figure()

    title = value_mapping["titles"][selected_index]
    metric = value_mapping["values"][selected_index]
    if title in ["Positive Word Rate", "Interaction Rate", "Active Review Rate"]:
        y1_values = target_df[metric] * 100  # Convert to percentage
    else:  
        y1_values = target_df[metric]
    
    y2_values = ((target_df[metric] / comps_df[metric]) - 1) * 100
    y3_values = ((target_df[metric] / LY_df[metric]) - 1 ) * 100  
    
    fig.add_trace(
        go.Bar(
            x=target_df[period].astype(str).tolist(),
            y=y1_values,
            name=f"Target - {metric}",
            hovertemplate = "Review Date: %{x}<br>" + title + ": %{y:.1f}<extra></extra>"
        )
    )

    fig.add_trace(
        go.Scatter(
            x=target_df[period].astype(str).tolist(),
            y=y2_values,
            mode='lines+markers',
            line_shape='spline',
            yaxis='y2',  # <-- This ensures the trace uses the right y-axis
            name=f"vsComps - {metric}",
            hovertemplate="Review Date: %{x}<br>vs Competitor: %{y:.1f}%<extra></extra>"
        )
    )

    fig.add_trace(
        go.Scatter(
            x=target_df[period].astype(str).tolist(),
            y=y3_values,
            mode='lines+markers',
            line_shape='spline',
            yaxis='y2',  # <-- This ensures the trace uses the right y-axis
            name=f"vsLY - {metric}",
            hovertemplate="Review Date: %{x}<br>vs Last Year: %{y:.1f}%<extra></extra>"
        )
    )

    fig.update_layout(
        yaxis2=dict(
            overlaying='y',
            side='right',
            title='Percentage'
        ),
        legend=dict(
            x=0.5,   # adjusts horizontal position. 0.5 means center.
            y=-0.2,  # adjusts vertical position. Negative values place it below.
            orientation='h',  # makes it horizontal
            xanchor='center'  # ensures it stays centered even when resizing
        ),
        margin=dict(  # Adjust these values to your needs
            l=50,  # left margin
            r=50,  # right margin
            b=50,  # bottom margin
            t=50,  # top margin
            pad=4  # padding
        )
    )

    return fig


#fig =  create_figure_for_metric('year_month',0, target_data_month_final,comps_data_month_final,LY_data_month_final, value_mapping)

#fig.show()

#####################################################################

### 4 - map

def country_name_to_code(country_name):
    # Handling special cases:
    if country_name.lower() == "abkhazia georgia":
        return "GEO"  # ISO code for Georgia
    
    try:
        return pycountry.countries.search_fuzzy(country_name)[0].alpha_3
    except LookupError:
        print(f"Warning: Couldn't map - {country_name} - to an ISO code.")
        return None

def create_map_for_metric(selected_layer, selected_index, target_map_data_final, comps_map_data_final, LY_map_data_final):
    title = value_mapping["titles"][selected_index]
    metric = value_mapping["values"][selected_index]

    filtered_data = target_map_data_final[target_map_data_final['reviewer_nationality'] != " "]
    merged_data = filtered_data.merge(comps_map_data_final, on='reviewer_nationality', suffixes=('', '_comps')).merge(LY_map_data_final, on='reviewer_nationality', suffixes=('', '_LY'))

    # 计算 vsComps 和 vsLY
    merged_data['vsComps'] = round((merged_data[metric] / merged_data[metric + '_comps'] - 1),3) * 100
    merged_data['vsLY'] = round((merged_data[metric] / merged_data[metric + '_LY'] - 1),3) * 100

    country_codes = merged_data['reviewer_nationality'].apply(country_name_to_code)

    colorscale_blue = [
        [0, '#e6f2ff'],  # Lightest blue
        [1, '#5662FB']  # Darkest blue
    ]

    colorscale_RdWtGn = [
        [0, '#FB5656'],  # red
        [0.5, '#FFFFFF'],  # white
        [1, '#2ACD96']  # green
    ]

    if selected_layer == 'Target':
        fig_data = {
            'locations': country_codes,
            'z': round(merged_data[metric],2),
            'colorscale': colorscale_blue,
            'zmin': merged_data[metric].quantile(0.05),
            'zmax': merged_data[metric].quantile(0.95)
        }
    elif selected_layer == 'vsComps':
        fig_data = {
            'locations': country_codes,
            'z': merged_data['vsComps'],
            'colorscale': colorscale_RdWtGn,
            'zmin': merged_data['vsComps'].quantile(0.05),
            'zmax': merged_data['vsComps'].quantile(0.95)
        }
    else:
        fig_data = {
            'locations': country_codes,
            'z': merged_data['vsLY'],
            'colorscale': colorscale_RdWtGn,
            'zmin': merged_data['vsLY'].quantile(0.05),
            'zmax': merged_data['vsLY'].quantile(0.95)
        }

    fig = go.Figure(
        go.Choropleth(
            locations=fig_data['locations'],
            z=fig_data['z'],
            zmin=fig_data['zmin'],  # use zmin from fig_data
            zmax=fig_data['zmax'],  # use zmax from fig_data
            hovertext=merged_data['reviewer_nationality'],
            colorscale=fig_data['colorscale'],
            colorbar=dict(
                title=title,
                thickness=10,  
                x=0.5, 
                y=1,  
                yanchor="top",  
                orientation="h" 
            )
        )
    )

    fig.update_layout(
        geo=dict(
            showframe=False,
            showcoastlines=True,
            showcountries=True,
            projection_type='equirectangular',
            countrycolor="#D3D3D3"
        ),
        margin=dict(t=20, b=40, l=10, r=10)  
    )

    return fig



#fig = create_map_for_metric('Target',0)
#fig.show()



#####################################################################

### 5 - wordcloud

def red_color_func(word, font_size, position, orientation, random_state=None, **kwargs):
    return "hsl(0, 100%%, %d%%)" % random.randint(30, 60)

def blue_color_func(word, font_size, position, orientation, random_state=None, **kwargs):
    return "hsl(240, 100%%, %d%%)" % random.randint(30, 60)

def create_wordcloud(text, mask, stopwords, color_func):
    return WordCloud(
        mask=mask,
        background_color="white",
        stopwords=stopwords,
        contour_width=1,
        contour_color='black',
        color_func=color_func
    ).generate(text)

def generate_wordcloud_figures(data_filtered):
    positive_mask = np.array(Image.open("positiveshape.png"))
    negative_mask = np.array(Image.open("negativeshape.png"))

    # Updated stopwords
    stopwords = set(STOPWORDS)
    stopwords.update(["hotel", "room", "positive", "negative", "t" ,"nothing", "could"])

    # Define the data and masks to be used
    def filter_reviews(series):
        series = series.str.lower()
        return series[~series.isin(["nothing", "no positive", "no negative"])].dropna()

    filtered_negative_reviews = filter_reviews(data_filtered["NR"])
    filtered_positive_reviews = filter_reviews(data_filtered["PR"])

    review_data = {
        'negative': (" ".join(filtered_negative_reviews), red_color_func, negative_mask),
        'positive': (" ".join(filtered_positive_reviews), blue_color_func, positive_mask),
    }

    figures = {}
    for key, (reviews, color_func, mask) in review_data.items():
        wordcloud = create_wordcloud(reviews, mask, stopwords, color_func)
        figures[key] = px.imshow(np.array(wordcloud))
        figures[key].update_layout(xaxis=dict(showgrid=False, zeroline=False, visible=False),
                                   yaxis=dict(showgrid=False, zeroline=False, visible=False),
                                   showlegend=False,
                                   plot_bgcolor='rgba(0,0,0,0)',
                                   paper_bgcolor='rgba(0,0,0,0)',
                                    margin=dict(t=10, b=10, l=10, r=10)  
                                   )
    return figures


#figures['negative'].show()
#figures['positive'].show()
#figures['positive_comps'].show()

#####################################################################

### 6 - factors table
def generate_datatables(df_pos, df_neg):
    pos_factors = dash_table.DataTable(
        id='table-pos',
        columns=[{"name": i, "id": i} for i in df_pos.columns],
        data=df_pos.to_dict('records'),
        style_cell={'textAlign': 'center', 'fontFamily': 'Arial'},
        style_header={
            'backgroundColor': '#BFD1FD',
            'fontWeight': 'bold',
            'fontFamily': 'Arial'
        }
    )

    neg_factors = dash_table.DataTable(
        id='table-neg',
        columns=[{"name": i, "id": i} for i in df_neg.columns],
        data=df_neg.to_dict('records'),
        style_cell={'textAlign': 'center', 'fontFamily': 'Arial'},
        style_header={
            'backgroundColor': '#BFD1FD',
            'fontWeight': 'bold',
            'fontFamily': 'Arial'
        }
    )

    return pos_factors, neg_factors


#####################################################################

### 7 - list
import re

def create_review_card(review_text, sentiment, search_value=""):
    if search_value:
        parts = re.split(f'({re.escape(search_value)})', review_text, flags=re.IGNORECASE)
        highlighted_review = []
        for part in parts:
            if part.lower() == search_value.lower():
                highlighted_review.append(html.Span(part, style={"background-color": "yellow"}))
            else:
                highlighted_review.append(part)
    else:
        highlighted_review = review_text

    card_content = [
        dbc.CardBody(
            [
                html.Div([
                    create_icons_for_sentiment(sentiment),
                    html.Small(f"Sentiment Score: {sentiment:.2f}", className="text-right")
                ], style={'display': 'flex', 'justify-content': 'space-between', 'align-items': 'center'}),
                html.P(highlighted_review, className="card-text")
            ]
        ),
    ]
    return dbc.Card(card_content, style={"margin": "10px"})

def create_icons_for_sentiment(sentiment_score):
    icons = []
    if sentiment_score >= 0:
        filled_icons_count = int(sentiment_score * 5)
    else:
        filled_icons_count = 5 - int(abs(sentiment_score) * 5)

    for i in range(5):
        if sentiment_score < 0:
            if i < filled_icons_count:
                icon = html.I(className="bi bi-emoji-angry", style={"color": "red"})
            else:
                icon = html.I(className="bi bi-emoji-angry-fill", style={"color": "red"})
        else:
            if i < filled_icons_count:
                icon = html.I(className="bi bi-emoji-laughing-fill", style={"color": "green"})
            else:
                icon = html.I(className="bi bi-emoji-laughing", style={"color": "green"})
        icons.append(icon)
    return html.Div(icons, style={'display': 'flex', 'justify-content': 'space-between'})

def review_card_components(data_filtered):
    
    negative_reviews = data_filtered["NR"].dropna()
    negative_sentiments = [TextBlob(review).sentiment.polarity for review in negative_reviews]
    sorted_reviews_and_sentiments = sorted(zip(negative_reviews, negative_sentiments), key=lambda x: x[1])
    sorted_reviews, sorted_sentiments = zip(*sorted_reviews_and_sentiments)
    
    positive_reviews = data_filtered["PR"].dropna()
    positive_sentiments = [TextBlob(review).sentiment.polarity for review in positive_reviews]
    sorted_positive_reviews_and_sentiments = sorted(zip(positive_reviews, positive_sentiments), key=lambda x: x[1], reverse=True)
    sorted_positive_reviews, sorted_positive_sentiments = zip(*sorted_positive_reviews_and_sentiments)

    negative_search_box = dcc.Input(
        id='negative-search-box', 
        type='text', 
        placeholder='Search in Negative Reviews...',
        style={'height': '40px', 'padding': '5px 10px', 'box-sizing': 'border-box'}
    )

    positive_search_box = dcc.Input(
        id='positive-search-box', 
        type='text', 
        placeholder='Search in Positive Reviews...',
        style={'height': '40px', 'padding': '5px 10px', 'box-sizing': 'border-box'}
    )

    review_cards = html.Div([
        html.Div([
            html.H5("Negative Comments Detail", style={"flex": "1"}),
            negative_search_box
        ], style={'display': 'flex', 'justify-content': 'space-between', 'align-items': 'center'}),
        html.Div(
            id="reviews-container",
            className="card-container"
        ),
        html.Div(
            dbc.Pagination(
                id="pagination",
                max_value=(len(sorted_reviews) + 5) // 6, 
                active_page=1,
                first_last=True,
                previous_next=True,
                fully_expanded=False,
            ),
        style={
            "display": "flex",
            "justifyContent": "center"
        }
        )
    ])

    positive_review_cards = html.Div([
        html.Div([
            html.H5("Positive Comments Detail", style={"flex": "1"}),
            positive_search_box
        ], style={'display': 'flex', 'justify-content': 'space-between', 'align-items': 'center'}),
        html.Div(
            id="positive-reviews-container",
            className="card-container"
        ),
        html.Div(
            dbc.Pagination(
                id="positive-pagination",
                max_value=(len(sorted_reviews) + 5) // 6, 
                active_page=1,
                first_last=True,
                previous_next=True,
                fully_expanded=False,
            ),
        style={
            "display": "flex",
            "justifyContent": "center"
        }
        )
    ])
    
    return review_cards, positive_review_cards, sorted_reviews_and_sentiments, sorted_positive_reviews_and_sentiments


